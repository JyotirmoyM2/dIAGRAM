import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { NiceSelectModule } from "ng-nice-select";
import { MalihuScrollbarModule } from 'ngx-malihu-scrollbar';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { AddCaptureComponent } from './add-capture/add-capture.component';

// Imported Syncfusion RichTextEditorModule from Rich Text Editor package
import { RichTextEditorModule } from '@syncfusion/ej2-angular-richtexteditor';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AddCaptureComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    RichTextEditorModule,
    NiceSelectModule,
    MalihuScrollbarModule.forRoot(),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
